<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('blog_id')->index();
            $table->text('type');
            $table->jsonb('content');
            $table->json('layout');
            $table->text('url');
            $table->date('date');
            $table->timestamp('timestamp');
            $table->text('format');
            $table->text('source_url');
            $table->integer('reblog_key');
            $table->text('blog_name');
            $table->boolean('mobile');
            $table->text('source_title');
            $table->text('post_state');
            $table->integer('parent_post_id');
            $table->integer('parent_blog_id')->comment("connect to id in blog table");
            $table->text('post_ask_submit');
            $table->integer('target_user_id');
            $table->boolean('is_anonymous');
            $table->boolean('is_apporved');
            $table->text('post_summary');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
}
