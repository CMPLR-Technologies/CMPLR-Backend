<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBlogTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blog', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('user_id');
            $table->text('name');
            $table->text('url');
            $table->text('title');
            $table->boolean('primary');
            $table->integer('followers');
            $table->text('type');
            $table->text('password');
            $table->boolean('full_priveleges');
            $table->boolean('contributor_priveleges');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('blog');
    }
}
