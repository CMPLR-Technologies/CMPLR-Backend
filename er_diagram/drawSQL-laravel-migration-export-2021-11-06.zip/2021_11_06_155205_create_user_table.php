<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->text('email')->unique();
            $table->text('passoword');
            $table->text('first_name');
            $table->text('last_name');
            $table->integer('following_count');
            $table->integer('likes_count');
            $table->text('default_post_format');
            $table->text('login_options');
            $table->boolean('email_activity_check');
            $table->boolean('TFA');
            $table->json('filter_tags');
            $table->boolean('endless_scrolling');
            $table->boolean('show_badge');
            $table->text('text_editor');
            $table->boolean('msg_sound');
            $table->boolean('best_stuff_first');
            $table->boolean('include_followed_tag');
            $table->boolean('tumblr_news');
            $table->boolean('conversational_notification');
            $table->json('filtering_content');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user');
    }
}
