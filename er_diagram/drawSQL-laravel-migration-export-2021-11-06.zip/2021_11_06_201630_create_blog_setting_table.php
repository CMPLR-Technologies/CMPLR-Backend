<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBlogSettingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blog_setting', function (Blueprint $table) {
            $table->integer('blog_id')->primary();
            $table->boolean('repiles');
            $table->boolean('allow_ask');
            $table->boolean('ask_page_title');
            $table->boolean('allow_anonymous_question');
            $table->boolean('allow_submissions');
            $table->text('submission_page_title');
            $table->text('submission_guidelines');
            $table->boolean('is_text_allowed');
            $table->boolean('is_photo_allowed');
            $table->boolean('is_link_allowed');
            $table->boolean('is_quote_allowed');
            $table->boolean('is_video_allowed');
            $table->boolean('allow_messaging');
            $table->integer('posts_per_day');
            $table->integer('posts_start');
            $table->integer('posts_end');
            $table->boolean('dashboard_hide');
            $table->boolean('search_hide');
            $table->text('header_image');
            $table->text('avatar');
            $table->text('avatar_shape');
            $table->text('background_color');
            $table->text('accent_color');
            $table->boolean('show_header_image');
            $table->boolean('show_avatar');
            $table->boolean('show_title');
            $table->boolean('show_description');
            $table->boolean('use_new_post_type');
            $table->text('layout');
            $table->boolean('show_navigation');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('blog_setting');
    }
}
